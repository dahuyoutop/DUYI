const syb = Symbol();

console.log(syb);