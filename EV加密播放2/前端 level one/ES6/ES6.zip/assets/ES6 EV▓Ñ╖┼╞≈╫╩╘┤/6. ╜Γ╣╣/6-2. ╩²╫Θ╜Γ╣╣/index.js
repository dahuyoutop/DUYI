let a = 1, b = 2;

[b, a] = [a, b]

console.log(a, b)