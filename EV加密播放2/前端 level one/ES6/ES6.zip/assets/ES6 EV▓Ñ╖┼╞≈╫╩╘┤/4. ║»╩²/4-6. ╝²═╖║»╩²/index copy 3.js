//判断一个数是不是奇数
// const isOdd = function (num) {
//     return num % 2 !== 0;
// }

// const isOdd = (num) => {
//     return num % 2 !== 0;
// }

const isOdd = num => num % 2 !== 0;

console.log(isOdd(3))
console.log(isOdd(4))