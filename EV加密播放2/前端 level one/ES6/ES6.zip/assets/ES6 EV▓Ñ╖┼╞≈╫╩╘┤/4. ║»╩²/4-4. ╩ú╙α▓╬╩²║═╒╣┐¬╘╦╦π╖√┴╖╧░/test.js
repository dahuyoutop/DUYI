function test(a, b, c) {
    console.log(a, b, c);
}

test(2, 6, 7);

const arr = ["asf", "Gfh", "111"];

test(...arr);