var obj = {
  a: 1,
  b: 2,
};

const proxy = new Proxy(obj, {
  set(target, key, value) {
    // console.log(`给属性${key}赋值为${value}`);
    // target[key] = value;
    console.log("有个年轻人想给对象赋值，我可以悄悄的做一些事");
    Reflect.set(target, key, value);
  },
  get(target, key) {
    console.log("有个年轻人想取值，我可以悄悄的做一些事");
    return Reflect.get(target, key);
  },
  deleteProperty(target, key) {
    // delete target[key];
    Reflect.deleteProperty(target, key);
  },
});

// proxy.a = 3; // set(obj, "a", 3)
// console.log(proxy.asdfasdfafda); // get(obj, "asdfasdfafda")
// delete proxy.a; // deleteProperty(obj, "a");
proxy.a = 3;
console.log(proxy.a);
