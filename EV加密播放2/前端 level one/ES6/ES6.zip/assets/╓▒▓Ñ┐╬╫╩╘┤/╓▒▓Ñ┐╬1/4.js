// var person;

// console.log(person?.address?.city);

// var a = 5;

// // a存在就取它的值，不存在就取默认值
// const b = a ?? 1;
// console.log(b);
