var obj = {
  a: 1,
  b: 2,
};

console.log(Object.keys(obj)); // ES5
console.log(Object.values(obj)); // ES6
console.log(Object.entries(obj)); // ES6
