import staticModule from "./staticModule.js";

console.log(staticModule);

setTimeout(async () => {
  const module = await import("./dynamicModule.js");
  console.log(module.default);
}, 3000);
