var user = {
  name: "monica",
  age: 17,
  test() {
    const sayHello = () => {
      console.log(this);
      // 如何得到全局呢？？？？
      console.log(globalThis);
    };
    sayHello();
  },
};

user.test();
