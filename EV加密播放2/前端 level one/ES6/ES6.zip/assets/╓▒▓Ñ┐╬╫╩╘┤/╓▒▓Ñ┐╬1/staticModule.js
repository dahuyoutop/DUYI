export default "staticModule";
