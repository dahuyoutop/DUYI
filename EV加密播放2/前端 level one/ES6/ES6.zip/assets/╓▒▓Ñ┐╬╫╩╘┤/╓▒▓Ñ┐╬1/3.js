// var obj = {
//   a: 1,
//   b: 2,
// };

// const entries = Object.entries(obj);
// // var obj2 = {};
// // for (const [k, v] of entries) {
// //   obj2[k] = v;
// // }
// // console.log(obj2);
// const obj2 = Object.fromEntries(entries);
// console.log(obj2);

function localMoneyFomat(obj) {
  //略
  const result = Object.entries(obj).map(([k, v]) =>
    typeof v === "number" ? [k, `￥${v}`] : [k, v]
  );
  return Object.fromEntries(result);
}

var obj = {
  name: "xxx",
  balance: 199.8, //余额
  taken: 3000, //消费
};
const newObj = localMoneyFomat(obj);
console.log(newObj); // {name:"xxx", balance:"￥199.8", taken: "￥3000"}
