// const arr = [1, 2, 3, 4, 5];

// /*
//     [
//         {number:1, doubleNumber: 2},
//         {number:3, doubleNumber: 6},
//         {number:5, doubleNumber: 10},
//     ]
// */
// // const arr1 = arr
// //   .filter((it) => it % 2 !== 0)
// //   .map((it) => ({ number: it, doubleNumber: it * 2 }));
// // console.log(arr1);

// const arr2 = arr.flatMap((it) =>
//   it % 2 === 0 ? [] : { number: it, doubleNumber: it * 2 }
// );

// console.log(arr2);

const arr = [
  "Yestoday is a History",
  "Tomorrow is a Mystery",
  "Today is a Gift",
  "That's why we call it the Present",
];

/*
  ["Yestoday", "is", "a", "History", "Tomorrow", ...]
*/
var arr2 = arr.flatMap((it) => it.split(" "));
console.log(arr2);
