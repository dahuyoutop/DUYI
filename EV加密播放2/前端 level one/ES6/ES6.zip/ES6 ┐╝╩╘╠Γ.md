# ES6考试题

[考试题](https://duyiedu.yuque.com/docs/share/0d2322fd-adb6-4b33-9d61-e79fd463330a?)

[答案](https://duyiedu.yuque.com/docs/share/c9f2fbf2-b555-4ced-aca5-5114e9d3ea54)

一、 选择题（均为单选题，每小题2分，共24题， 48分）

`ABBCD` `DACBA` `CC??B` `A??A?` `ACC?`

二、填空题（每空1分，共12空， 12分）

1. `new.target`
2. `:`
3. `?` `resp` `then`
4. `?` `剩余参数`
5. `resolve` `抛出错误` `rejected`
6. `可迭代协议` `iterator`

三、简答题（共2题，每题10分， 20分）

1. 阐述Promise解决了什么问题，它如何解决的，async和await又解决了什么问题？

`Promise 解决了异步处理的问题; async 和 await 让 promise 书写起来更加方便`

---

`Promise使用一种标准的模式来解决异步问题，使得异步处理有章可循。它将一个异步任务分为两个阶段，unsettled和settled，unsettled阶段有权力将异步任务推向settled阶段。同时，它将异步任务划分为3种状态：pending、resolved、rejected，无论是resolved还是rejected，都属于settled阶段，pending一定属于unsettled阶段。状态一定是从pending改变到resolved或rejected中的任意一种，一旦改变，状态不可逆。状态可以附带数据，该数据可以被后续处理所接收。后续处理通过then或catch注册，有两种，分别处理resolved状态或rejected状态。`

`async和await是ES7的关键字，用于进一步简化Promise的操作，它可以让我们像编写同步代码那样处理Promise`

2. 阐述什么是迭代器、可迭代协议、可迭代对象、生成器

- 迭代器: `对迭代过程的封装，在不同的语言中有不同的表现形式，通常为对象`
- 可迭代协议: `ES6规定，如果一个对象具有知名符号属性Symbol.iterator，并且属性值是一个迭代器创建函数，则该对象是可迭代的（iterable）`
- 可迭代对象:

```js
const obj = {
    [Symbol.iterator]() {
        return {
            next() {
                return {
                    value: 1,
                    done: false
                }
            }
        }
    }
}
```

- 生成器: `生成器是一个通过构造函数Generator创建的对象，生成器既是一个迭代器，同时又是一个可迭代对象`

---

`迭代器是一个普通的对象，内部提供了next方法，调用后得到一个包含value和done属性的对象，value属性表示这一次迭代得到的数据，done指示是否迭代完成。`
`可迭代协议是一个规范，如果某个对象拥有知名符号Symbol.iterator，并且该符号是一个迭代器创建函数，则该对象满足可迭代协议`
`只要满足可迭代协议的对象，称之为可迭代对象`
`生成器本质上既是一个可迭代对象、又是一个迭代器。它是由生成器函数创建的。生成器函数一定返回一个生成器，它的出现是为了方便迭代器的编写，我们可以通过yield关键字不断的产生迭代结果，并且通过生成器控制迭代过程`

四、编程题（共2题，每题10分，20分）

