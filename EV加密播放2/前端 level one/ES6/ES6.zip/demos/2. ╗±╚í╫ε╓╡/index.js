const maxNumContainer = document.querySelector('.maxNum');
const minNumContainer = document.querySelector('.minNum');
const btn = document.querySelector('.btn');

/**
 * 获取页面中所有数字文本框中的数值组成的数组
 */
function getValues() {
    const arr = [];
    const inps = document.querySelectorAll('input[type="number"]');
    inps.forEach(inp => {
        arr.push(inp.value);
    });
    return arr;
}


btn.onclick = function () {
    const values = getValues();

    maxNumContainer.innerHTML = Math.max(...values);
    minNumContainer.innerHTML = Math.min(...values);
}